# EvidScope evidence package summary: EU AI Act: record-keeping, logs and human oversight

> "Evidence present" is not a finding that a requirement is met. Legal judgement stays with people reading the sources.
> Generated from index.json; the verifier regenerates it and compares every byte.

## Verified evidence

- Signed export: tenant alpha, 45 records, head `47893723a0d6e464e0464cf48642d6e1446c9dbafd557aede51296ebd4e8ad9a`, evaluation replay 4/4 (mismatch 0, not replayable 0)
- Period (recordedAt): all; 45/45 records
- Case reports: evidence/case-reports/case-1.json (stale)

## Items

- [EU-AIA-12-1] Regulation (EU) 2024/1689, Article 12(1) — Automatic recording of events (logs) over the lifetime of the system: **evidence present** — signed\_ledger 45, record event 7 (seq 18–30), record event\_receipt 7 (seq 19–31)
- [EU-AIA-12-2-A] Regulation (EU) 2024/1689, Article 12(2)(a) — Events relevant for identifying risk situations (Article 79(1)) or a substantial modification: **evidence present** — record evaluation 4 (seq 33–45), record agent\_registry 5 (seq 4–43), record agent\_transition 6 (seq 5–42), record agent\_stop\_order 1 (seq 41)
- [EU-AIA-12-2-B] Regulation (EU) 2024/1689, Article 12(2)(b) — Events relevant for post-market monitoring (Article 72): **evidence present** — record evaluation 4 (seq 33–45)
- [EU-AIA-12-2-C] Regulation (EU) 2024/1689, Article 12(2)(c) — Events relevant for monitoring the operation (Article 26(5)): **evidence present** — event intent/agent 2 (seq 20–26), event execution/tool 2 (seq 22–28), event policy\_decision/enforcement 2 (seq 18–24)
- [EU-AIA-19-1] Regulation (EU) 2024/1689, Article 19(1) — Providers keep the automatically generated logs under their control (at least six months): **evidence present** — signed\_ledger 45, record retention\_policy 1 (seq 32)
- [EU-AIA-26-6] Regulation (EU) 2024/1689, Article 26(6) — Deployers keep the automatically generated logs under their control (at least six months): **evidence present** — signed\_ledger 45, record retention\_policy 1 (seq 32)
- [EU-AIA-72-1-2] Regulation (EU) 2024/1689, Article 72(1) and (2) — Post-market monitoring: collect, document and analyse data on performance: **evidence present** — record evaluation 4 (seq 33–45), record case 1 (seq 39), record case\_decision 1 (seq 40) → evidence/case-reports/case-1.json
- [EU-AIA-14-4-A] Regulation (EU) 2024/1689, Article 14(4)(a) — Overseers monitor the operation and detect anomalies, dysfunctions and unexpected performance: **evidence present** — record case 1 (seq 39), record case\_decision 1 (seq 40) → evidence/case-reports/case-1.json
- [EU-AIA-14-4-D] Regulation (EU) 2024/1689, Article 14(4)(d) — Overseers decide not to use, or disregard, override or reverse the output: **evidence present** — record approval\_request 5 (seq 13–17), event human\_approval/authority 1 (seq 30), record case\_decision 1 (seq 40) → evidence/case-reports/case-1.json
- [EU-AIA-14-4-E] Regulation (EU) 2024/1689, Article 14(4)(e) — Overseers intervene or interrupt the system through a stop button or similar procedure: **evidence present** — record agent\_stop\_order 1 (seq 41)

## Provisions not mapped

- Article 12(3), Article 14(5): Annex III point 1(a) systems (remote biometric identification): the listed log content and two-person verification are not modelled.
- Article 19(2), Article 26(6) second subparagraph: Financial institutions keep logs in the documentation of financial services law, outside EvidScope.
- Article 14(4)(b) and (c): Awareness of automation bias and interpretation of output are design and training measures, not recorded events.

## What this package does not prove

- That any legal requirement is met or that a certification criterion is satisfied; the mapping itself is a draft for human review.
- Completeness of collection: actions and sources not sent to EvidScope are invisible, and zero records does not mean that a control is absent.
- Truth of self-reported fields (occurredAt, status, measurements): the signature covers what the vault received.
- Without an external checkpoint or witnesses, a host holding the signing key could roll back or truncate the ledger.
