# EvidScope 증거 묶음 요약: EU AI Act: 기록 보존·로그·사람 감독

> "증거 있음"은 요구사항을 충족했다는 판정이 아닙니다. 법적 판단은 사람이 원문과 함께 합니다.
> 이 요약은 index.json에서 생성되었고 검증기가 다시 생성해 바이트 단위로 대조합니다.

## 검증한 증거

- 서명 내보내기: tenant alpha, 45 기록, head `47893723a0d6e464e0464cf48642d6e1446c9dbafd557aede51296ebd4e8ad9a`, 평가 재계산 4/4 (mismatch 0, not replayable 0)
- 기간(recordedAt): 전체; 45/45 기록
- 사건 보고서: evidence/case-reports/case-1.json (stale)

## 항목

- [EU-AIA-12-1] Regulation (EU) 2024/1689, Article 12(1) — 시스템 수명 동안 이벤트(로그)의 자동 기록: **증거 있음** — signed\_ledger 45, record event 7 (seq 18–30), record event\_receipt 7 (seq 19–31)
- [EU-AIA-12-2-A] Regulation (EU) 2024/1689, Article 12(2)(a) — 위험 상황(제79조제1항) 또는 실질적 변경을 식별하는 데 관련된 이벤트: **증거 있음** — record evaluation 4 (seq 33–45), record agent\_registry 5 (seq 4–43), record agent\_transition 6 (seq 5–42), record agent\_stop\_order 1 (seq 41)
- [EU-AIA-12-2-B] Regulation (EU) 2024/1689, Article 12(2)(b) — 시판 후 모니터링(제72조)에 관련된 이벤트: **증거 있음** — record evaluation 4 (seq 33–45)
- [EU-AIA-12-2-C] Regulation (EU) 2024/1689, Article 12(2)(c) — 운영 모니터링(제26조제5항)에 관련된 이벤트: **증거 있음** — event intent/agent 2 (seq 20–26), event execution/tool 2 (seq 22–28), event policy\_decision/enforcement 2 (seq 18–24)
- [EU-AIA-19-1] Regulation (EU) 2024/1689, Article 19(1) — 제공자의 자동 생성 로그 보관(최소 6개월): **증거 있음** — signed\_ledger 45, record retention\_policy 1 (seq 32)
- [EU-AIA-26-6] Regulation (EU) 2024/1689, Article 26(6) — 배포자의 자동 생성 로그 보관(최소 6개월): **증거 있음** — signed\_ledger 45, record retention\_policy 1 (seq 32)
- [EU-AIA-72-1-2] Regulation (EU) 2024/1689, Article 72(1) and (2) — 시판 후 모니터링: 성능 자료의 수집·문서화·분석: **증거 있음** — record evaluation 4 (seq 33–45), record case 1 (seq 39), record case\_decision 1 (seq 40) → evidence/case-reports/case-1.json
- [EU-AIA-14-4-A] Regulation (EU) 2024/1689, Article 14(4)(a) — 감독자가 운영을 모니터링하고 이상·오작동·예상 밖 성능을 탐지: **증거 있음** — record case 1 (seq 39), record case\_decision 1 (seq 40) → evidence/case-reports/case-1.json
- [EU-AIA-14-4-D] Regulation (EU) 2024/1689, Article 14(4)(d) — 감독자가 사용하지 않거나 출력을 무시·무효화·되돌리기로 결정: **증거 있음** — record approval\_request 5 (seq 13–17), event human\_approval/authority 1 (seq 30), record case\_decision 1 (seq 40) → evidence/case-reports/case-1.json
- [EU-AIA-14-4-E] Regulation (EU) 2024/1689, Article 14(4)(e) — 감독자가 정지 버튼 등으로 개입하거나 시스템을 중단: **증거 있음** — record agent\_stop\_order 1 (seq 41)

## 대응하지 않은 조항

- Article 12(3), Article 14(5): 부속서 III 1(a) 원격 생체 식별 시스템의 지정 로그 내용과 2인 확인은 EvidScope가 모델링하지 않습니다.
- Article 19(2), Article 26(6) second subparagraph: 금융기관은 금융 서비스 법령의 문서로 로그를 보관하며 EvidScope 밖입니다.
- Article 14(4)(b) and (c): 자동화 편향 인식과 출력 해석은 설계·교육 조치이며 기록되는 이벤트가 아닙니다.

## 이 묶음이 증명하지 않는 것

- 법적 요구사항의 충족이나 인증 적합성. 대응표 자체가 사람 검토 전 초안입니다.
- 수집의 완전성. EvidScope에 보내지 않은 행동과 출처는 보이지 않으며, 0건은 통제가 없다는 뜻이 아닙니다.
- 출처가 스스로 보고한 내용(occurredAt, 상태, 측정값)의 진실성. 서명은 vault가 받은 기록을 보증할 뿐입니다.
- 외부 체크포인트나 위트니스 없이 검증하면 서명 키를 가진 호스트의 되돌리기·잘라내기를 배제하지 못합니다.
