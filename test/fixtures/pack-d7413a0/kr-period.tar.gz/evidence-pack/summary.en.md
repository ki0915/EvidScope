# EvidScope evidence package summary: Korean AI Basic Act: registered requirements

> "Evidence present" is not a finding that a requirement is met. Legal judgement stays with people reading the sources.
> Generated from index.json; the verifier regenerates it and compares every byte.

## Verified evidence

- Signed export: tenant alpha, 45 records, head `47893723a0d6e464e0464cf48642d6e1446c9dbafd557aede51296ebd4e8ad9a`, evaluation replay 4/4 (mismatch 0, not replayable 0)
- Period (recordedAt): 2026-10-08T04:04:08.250Z – 2026-10-08T04:04:08.707Z; 34/45 records
- Case reports: none

## Items

- [KR-31-1] 인공지능기본법 제31조제1항 / 시행령 제23조 — AI 사용 사전 고지: **no evidence recorded**; human judgement: none
- [KR-31-2] 인공지능기본법 제31조제2항 / 시행령 제23조제2항 — 생성형 결과물 표시: **no evidence recorded**; human judgement: none
- [KR-31-3] 인공지능기본법 제31조제3항 / 시행령 제23조제3항 — 사실적인 합성물의 명확한 고지: **no evidence recorded**; human judgement: none
- [KR-32-RISK] 인공지능기본법 제32조제1항제1호 / 시행령 제24조 — 안전성 위험 식별·평가·완화: **evidence present** — record evaluation 2 (seq 33–34), record agent\_registry\_policy 1 (seq 2); human judgement: none
- [KR-32-MONITOR] 인공지능기본법 제32조제1항제2호 / 시행령 제24조 — 안전사고 모니터링·대응 체계: **evidence present** — record evaluation 2 (seq 33–34); human judgement: none
- [KR-32-SUBMIT] 인공지능기본법 제32조제2항·제3항 — 안전성 이행 결과 제출: **no evidence recorded**; human judgement: none
- [KR-33] 인공지능기본법 제33조제1항 / 시행령 제25조 — 고영향 해당 여부 사전 검토: **no evidence recorded**; human judgement: none
- [KR-34-RISK] 인공지능기본법 제34조제1항제1호 — 고영향 위험관리: **evidence present** — record evaluation 2 (seq 33–34), record agent\_registry\_policy 1 (seq 2); human judgement: none
- [KR-34-EXPLAIN] 인공지능기본법 제34조제1항제2호 — 설명 방안: **no evidence recorded**; human judgement: none
- [KR-34-PROTECT] 인공지능기본법 제34조제1항제3호 — 이용자 보호: **no evidence recorded**; human judgement: none
- [KR-34-OVERSIGHT] 인공지능기본법 제34조제1항제4호 — 사람의 관리·감독: **evidence present** — record approval\_request 5 (seq 13–17), event human\_approval/authority 1 (seq 30); human judgement: none
- [KR-34-DOCUMENT] 인공지능기본법 제34조제1항제5호 / 시행령 제27조제1항·제2항 — 조치 문서·보관·게시: **evidence present** — record retention\_policy 1 (seq 32), signed\_ledger 45; human judgement: none
- [KR-35-IMPACT] 인공지능기본법 제35조제1항 / 시행령 제28조 — 기본권 영향평가와 취약계층: **no evidence recorded**; human judgement: none
- [KR-35-PUBLIC] 인공지능기본법 제35조제2항 — 공공 이용 시 평가 제품 우선 고려: **no evidence recorded**; human judgement: none
- [KR-30-EFFORT] 인공지능기본법 제30조제3항 — 고영향 AI 사전 검·인증 노력: **no evidence recorded**; human judgement: none
- [KR-30-PUBLIC] 인공지능기본법 제30조제4항 — 공공 이용 시 검·인증 AI 우선 고려: **no evidence recorded**; human judgement: none
- [KR-36-REPRESENTATIVE] 인공지능기본법 제36조제1항·제2항·제3항 / 시행령 제29조 — 국외 사업자의 국내대리인 지정·신고: **no evidence recorded**; human judgement: none
- [KR-40-ORDER] 인공지능기본법 제40조제1항·제2항·제3항 / 제43조제1항제3호 — 사실조사 자료와 중지·시정명령 이행: **no evidence recorded**; human judgement: none

## Provisions not mapped

- none

## What this package does not prove

- That any legal requirement is met or that a certification criterion is satisfied; the mapping itself is a draft for human review.
- Completeness of collection: actions and sources not sent to EvidScope are invisible, and zero records does not mean that a control is absent.
- Truth of self-reported fields (occurredAt, status, measurements): the signature covers what the vault received.
- Without an external checkpoint or witnesses, a host holding the signing key could roll back or truncate the ledger.
